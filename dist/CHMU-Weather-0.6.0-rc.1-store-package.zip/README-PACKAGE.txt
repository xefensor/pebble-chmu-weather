ČHMÚ Weather 0.6.0 release candidate 1

The exact PBW is at the root. store/ contains English/Czech listing text,
80/144px original icons and a publishing checklist. Privacy, provider/library
notices, licenses, feed notes and validation are included.

Plugins have no Store screenshot fields; docs/images are illustrative settings
previews. Pebble currently limits plugin publication to invited developers.
This archive is prepared for review/sideloading, not a Store submission.

The strict live weather smoke encountered the existing per-call timeouts; see
docs/VALIDATION.md for exact limits and remaining phone/network checks.

Use SHA256SUMS to verify each file. Source code and updates:
https://github.com/xefensor/pebble-chmu-weather
