ČHMÚ Weather 1.0.1

The exact PBW is at the root. store/ contains English/Czech listing text,
80/144px original icons and a publishing checklist. Privacy, provider/library
notices, licenses, feed notes and validation are included.

Plugins have no Store screenshot fields; docs/images are illustrative settings
previews. Upload the exact PBW using your enabled developer account.
Creating this archive does not perform a Store submission.

The public exact-PBW live smoke passed without app-backend requests; see
docs/VALIDATION.md for exact limits and remaining phone/network checks.

Use SHA256SUMS to verify each file. Source code and updates:
https://github.com/xefensor/pebble-chmu-weather
