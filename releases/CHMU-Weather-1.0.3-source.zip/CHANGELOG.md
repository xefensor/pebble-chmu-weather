# Changelog

## 1.0.3 — 2026-11-14

- Package the current reviewed implementation and updated Store assets under a new numeric version, preserving the public UUID and saved settings.
- Earlier released binaries and archives remain unchanged.

## 1.0.1

- Makes the default public build exclude the authenticated ČHMÚ app backend,
  its permission, daily summaries and clear-sky noon UV settings.
- Overrides inherited app-enabled settings and excludes old app caches and
  diagnostics; public settings cannot re-enable those channels.
- Keeps public station observations, ALADIN, and optional Open-Meteo completion.
  Public UV choices are Open-Meteo forecast peak or Off.
- Adds an explicitly built Personal provider with its own UUID and both app
  channels enabled by default, outside public distribution artifacts.
- Updates English/Czech settings, previews, privacy, attribution and Store copy.
- Checks both final PBW policies and defaults; public exact-bundle live smoke
  returns a fresh station observation with no app-backend requests.

## 1.0.0

- Promotes the 0.6.0 release candidate to the first stable release.
- Keeps the same weather algorithms, source contract, permissions and settings
  behavior; this promotion changes release version metadata and packaging.
- Includes the phone-only PBW, source archive, original plugin icons, bilingual
  listing copy, privacy/attribution notices and publishing checklist.
- Keeps live-service timeout results and remaining physical-device checks in
  validation independently of publication eligibility.

## 0.6.0 release candidate 1

- Reports the installed package version correctly in settings.
- Fails settings saves clearly when local storage rejects them, preserving the
  prior settings and diagnostics.
- Serializes settings changes, restores controls after errors, and prevents
  writes before a valid initial state has been confirmed.
- Refines settings spacing and hierarchy with clear current-reading cards,
  nearby station selection, separate source controls and expandable details.
- Adds English/Czech text and light/dark presentation.
- Prepares original weather icons, current listing text, privacy/source links,
  a publishing checklist and release/source bundles.
- Preserves the working timer-free native entrypoint, weather algorithms,
  source choices, cache ages, permissions and observation provenance.
- Remains a sideloadable plugin-preview candidate; publication is limited by
  Pebble's invitation requirement and this candidate's device checks.

## 0.5.1 runtime fix

- Removes forbidden native `setTimeout`/`clearTimeout` access from the entrypoint.
- Checks elapsed request budgets when native bridge calls finish and leaves
  pending-Promise cancellation to the host's source-session timeout.
- Adds regressions with throwing timer getters and corrects earlier smoke
  harness assumptions. The user subsequently reported the plugin working.

## 0.5.0 beta

- Adds conditional weather GETs using service-provided ETag or Last-Modified
  validators at the existing refresh windows and on manual Refresh.
- Reuses validated bodies on HTTP 304 without renewing their original download,
  source or measurement timestamps, or the six-hour forecast reuse limit.
- Avoids persisting weather bodies and retained context marked `no-store`.
- Retains bounded already-past ALADIN temperature/condition forecasts for today's
  Prague date, so a later run can recover morning context previously downloaded.
  Retained context never supplies observations or current/future forecasts.
- Keeps full ČHMÚ app daily aggregates first. If today's ALADIN coverage is still
  incomplete, uses a full Open-Meteo day when completion is on; otherwise labels
  an available partial range honestly.
- Preserves the existing providers, permissions, authentication and host-driven
  native Weather refresh schedule.


## 0.4.0 beta

- Adds measured humidity and wind from the same station and timestamp as the
  selected fresh temperature. Missing fields fall back independently to public
  forecasts, with measurement/source timestamps retained.
- Uses the richer ČHMÚ ten-minute climate graph and matching-time open-data
  observations, with freshness and quality checks.
- Lets Automatic try up to three eligible stations within 30 km, preferring a
  similar elevation. A manually selected station remains fixed.
- Limits the station picker to eligible nearby choices and shows distance and
  elevation.
- Adds clearer stale, network and coverage status, measurement age and the last
  successful update to settings diagnostics.
- Adds a separate **Preferred UV source** choice: ČHMÚ clear-sky noon (default), Open-Meteo
  cloud-aware forecast peak, or Off. The full-day forecast checkbox now controls
  only ČHMÚ local daily aggregates.
- Keeps UV and daily forecasts independent. ČHMÚ UV can work with full-day
  forecasts off; Open-Meteo UV requires completion to be enabled and never
  turns it on automatically.


## 0.3.0 beta

- Aligns Pebble's main Weather screen with the measured current temperature
  by blending that fresh observation into only the active hourly slot. Other
  hours retain their forecasts, with per-hour source metadata.
- Adds a default-enabled **Use ČHMÚ app data** setting for the official app
  service's clear-sky noon UV and three-day local daily aggregates.
- Uses fresh app daily ranges to avoid an incomplete high/low for today when
  the public hourly forecast no longer includes the morning.
- Preserves nearby station measurements for current temperature and the richer
  public ALADIN feed for hourly forecasts, humidity and wind.
- Labels UV meaning and source, retains its original update time, and falls
  back to Open-Meteo forecast peak UV only when completion is enabled.
- Keeps the app-data and Open-Meteo settings independent; turning either off
  excludes its new requests and cached weather values.
- Persists settings revisions so separate Pebble settings/source sessions
  cannot publish results from obsolete station or source choices.
- Uses a random plugin installation ID and its own service credentials, with
  no user sign-in or Android device identifier required.
- Adds the ČHMÚ app domain to permissions and explains its requests and local
  credential storage in the privacy information.
- Keeps later forecasts local; the national outlook is not used as a town
  forecast.

## 0.2.0

- Adds a default-enabled Open-Meteo supplement for today's peak UV, actual
  precipitation probabilities and local forecasts up to seven days.
- Keeps fresh ČHMÚ station measurements and valid ALADIN forecast fields first.
- Adds hourly/daily precipitation probability and fills missing forecast fields
  or incomplete/later daily forecasts from Open-Meteo when enabled.
- Adds calculated shade feels-like temperature with explicit input provenance.
- Uses official ČHMÚ icon meanings for available condition codes.
- Adds source diagnostics and a setting to disable both Open-Meteo requests
  and use of its cached values.
- Updates permissions, attribution and privacy text for the additional source.
- Continues to feed Pebble's native Weather app and timeline when selected as
  Weather provider; field visibility still depends on PebbleOS.

## 0.1.0

- First sideloadable beta of ČHMÚ Weather for Pebble.
- Prefers fresh nearby station air-temperature measurements, with real timestamps.
- Supplies ALADIN hourly and daily forecasts, model conditions and calculated sun times.
- Follows Pebble's saved locations and temperature/wind units.
- Includes offline caching, bounded requests, station overrides and source diagnostics.
